importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
    var body = String(message.getBody(new java.lang.String().getClass()));
    
    //create json object from string object
    body = JSON.parse(body);
    
    var data = body.data;
    if(data){
        var key = data.KEY;
        if(key && key.length > 0){
            var businessPartner = key[0].BUSINESSPARTNER;
            message.setProperty("business_partner_no", businessPartner);
        }
    }
    
    return message;
}